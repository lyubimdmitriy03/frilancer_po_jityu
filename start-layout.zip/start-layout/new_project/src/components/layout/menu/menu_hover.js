// navigation hover
export function menu_hover() {
	const menu_body = document.querySelector('.menu__body');
	const marker = document.createElement('span');
	const links = document.querySelectorAll('.menu__link');
	const active_item = document.querySelector('.menu__link--active');
	marker.setAttribute('id', 'marker');
	marker.setAttribute('class', 'marker__init-hidden');
	menu_body.insertBefore(marker, menu_body.firstElementChild);


	let hideTimeout;         // Таймер для затримки повернення маркера
	let markerEnabled = false; // Чи активований маркер (для адаптиву)

	// 🔹 Переміщуємо маркер під переданий елемент
	function moveMarker(link) {
		if (!markerEnabled) return;

		const textNode = link.querySelector('span') || link; // Орієнтуємось по span всередині
		const rect = textNode.getBoundingClientRect();
		const parentRect = link.closest('.menu__body').getBoundingClientRect();

		marker.classList.remove('marker__hidden');
		marker.style.width = rect.width + 'px';
		marker.style.left = (rect.left - parentRect.left) + 'px';
	}

	// 🔹 Ховаємо маркер (додаємо клас)
	function hideMarker() {
		if (marker) marker.classList.add('marker__hidden');
	}

	// 🔹 Вмикаємо маркер, якщо ширина екрана дозволяє
	function enableMarker() {
		if (markerEnabled) return;
		markerEnabled = true;

		links.forEach(link => {
			link.addEventListener('mouseenter', handleEnter);
			link.addEventListener('mouseleave', handleLeave);
		});

		if (active_item) moveMarker(active_item);
	}

	// 🔹 Вимикаємо маркер на мобільних
	function disableMarker() {
		if (!markerEnabled) return;
		markerEnabled = false;

		links.forEach(link => {
			link.removeEventListener('mouseenter', handleEnter);
			link.removeEventListener('mouseleave', handleLeave);
		});

		hideMarker();
	}

	// 🔹 Обробка наведення миші
	function handleEnter() {
		clearTimeout(hideTimeout);
		marker.classList.add('marker__hover');
		moveMarker(this);
	}

	// 🔹 Обробка виходу миші
	function handleLeave() {
		marker.classList.remove('marker__hover');

		if (active_item) {
			hideTimeout = setTimeout(() => {
				moveMarker(active_item);
			}, 300);
		} else {
			hideMarker();
		}
	}

	// 🔹 Перевіряємо розмір вікна
	function checkViewport() {
		if (window.innerWidth >= 768) {
			enableMarker();
		} else {
			disableMarker();
		}
	}

	// 🔹 Події при завантаженні сторінки
	function delay(ms) {
		return new Promise(resolve => setTimeout(resolve, ms));
	}

	async function initMarkerOnLoad() {
		checkViewport(); // Перевірка ширини екрану

		await delay(750); // Чекаємо DOM+рендер
		if (active_item && markerEnabled) {
			moveMarker(active_item); // Позиціонуємо маркер
		}

		await delay(500); // Ще трохи чекаємо (загалом 950ms)
		requestAnimationFrame(() => {
			marker.classList.remove('marker__init-hidden'); // Показуємо маркер
		});
	}

	window.addEventListener('load', initMarkerOnLoad);

	// 🔹 Події при зміні розміру вікна
	window.addEventListener('resize', () => {
		checkViewport();

		if (active_item && markerEnabled) {
			moveMarker(active_item);
		}
	});
}
