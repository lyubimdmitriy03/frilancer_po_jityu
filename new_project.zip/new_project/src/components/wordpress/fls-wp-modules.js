import '/components/layout/menu/menu.js'
import '/components/pages/index/index.js'