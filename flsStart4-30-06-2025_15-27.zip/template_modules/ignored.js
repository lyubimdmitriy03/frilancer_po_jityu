export const ignoredDirs = [
	'backend',
	'src/files',
	'node_modules',
	'dist',
	'.git',
	'src/styles/fonts'
]
export const ignoredFiles = [
	'package.json',
	'src/components/other/statistics/data.json',
	'src/components/layout/head/fonts-preload.html'
]