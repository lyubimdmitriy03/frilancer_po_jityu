export const plugins = {
	tailwindcss: {}
};