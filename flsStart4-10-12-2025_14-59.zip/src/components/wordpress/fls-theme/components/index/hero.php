<?
	$content = $args['content'];
?>